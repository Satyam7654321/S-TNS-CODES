// Function to start the game
function startGame() {
    // Player 01
    let randomNumber1 = Math.floor(Math.random() * 6) + 1;
    let randomImage1 = "images/dice" + randomNumber1 + ".png";
    let image1 = document.querySelectorAll("img")[0];
    image1.setAttribute("src", randomImage1);

    // Player 02
    let randomNumber2 = Math.floor(Math.random() * 6) + 1;
    let randomImage2 = "images/dice" + randomNumber2 + ".png";
    let image2 = document.querySelectorAll("img")[1];
    image2.setAttribute("src", randomImage2);

    // Player 03
    let randomNumber3 = Math.floor(Math.random() * 6) + 1;
    let randomImage3 = "images/dice" + randomNumber3 + ".png";
    let image3 = document.querySelectorAll("img")[2];
    image3.setAttribute("src", randomImage3);

    // Player 04
    let randomNumber4 = Math.floor(Math.random() * 6) + 1;
    let randomImage4 = "images/dice" + randomNumber4 + ".png";
    let image4 = document.querySelectorAll("img")[3];
    image4.setAttribute("src", randomImage4);

    // Determine the winner(s)
    let maxNumber = Math.max(randomNumber1, randomNumber2, randomNumber3, randomNumber4);
    let winners = [];

    if (randomNumber1 === maxNumber) winners.push("Player 01");
    if (randomNumber2 === maxNumber) winners.push("Player 02");
    if (randomNumber3 === maxNumber) winners.push("Player 03");
    if (randomNumber4 === maxNumber) winners.push("Player 04");

    // Display the result
    let resultText = winners.length > 1 ? "It's a tie between " + winners.join(", ") + "!" : winners[0] + " wins!";
    document.querySelector("h1").textContent = resultText;
}

// Function to exit the game
function exitGame() {
    document.querySelector("h1").textContent = "Game Over!";
    document.querySelectorAll("img").forEach(img => img.setAttribute("src", "images/dice6.png"));
}

// Attach event listeners to the buttons
document.getElementById("startButton").addEventListener("click", startGame);
document.getElementById("exitButton").addEventListener("click", exitGame);
