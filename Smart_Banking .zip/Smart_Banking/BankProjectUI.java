import javax.swing.*;
import java.awt.*;
import java.util.HashMap;
import java.util.Map;

// Account class to store account details
class Account {
    private int accountNumber;
    private String name;
    private double balance;

    public Account(int accountNumber, String name, double initialDeposit) {
        this.accountNumber = accountNumber;
        this.name = name;
        this.balance = initialDeposit;
    }

    public int getAccountNumber() {
        return accountNumber;
    }

    public String getName() {
        return name;
    }

    public double getBalance() {
        return balance;
    }

    // Deposit money into the account
    public void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
        }
    }

    // Withdraw money from the account
    public void withdraw(double amount) {
        if (amount > 0 && amount <= balance) {
            balance -= amount;
        }
    }

    // Return account details as a string
    public String displayAccount() {
        return "Account Number: " + accountNumber +
               "\nName: " + name +
               "\nBalance: " + balance;
    }
}

// Main class with Swing UI for the Bank Management System
public class BankProjectUI extends JFrame {
    private Map<Integer, Account> accounts = new HashMap<>();
    private int nextAccountNumber = 1001;

    public BankProjectUI() {
        setTitle("Bank Management System");
        setSize(400, 300);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // center on screen
        initUI();
    }

    // Initialize the UI components
    private void initUI() {
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(5, 1, 10, 10));
        
        JButton createAccountBtn = new JButton("Create New Account");
        createAccountBtn.addActionListener(e -> createAccount());
        
        JButton depositBtn = new JButton("Deposit Money");
        depositBtn.addActionListener(e -> depositMoney());
        
        JButton withdrawBtn = new JButton("Withdraw Money");
        withdrawBtn.addActionListener(e -> withdrawMoney());
        
        JButton displayBtn = new JButton("Display Account Details");
        displayBtn.addActionListener(e -> displayAccount());
        
        JButton exitBtn = new JButton("Exit");
        exitBtn.addActionListener(e -> System.exit(0));
        
        panel.add(createAccountBtn);
        panel.add(depositBtn);
        panel.add(withdrawBtn);
        panel.add(displayBtn);
        panel.add(exitBtn);
        
        add(panel, BorderLayout.CENTER);
    }

    // Create a new account using input dialogs
    private void createAccount() {
        String name = JOptionPane.showInputDialog(this, "Enter your name:");
        if (name == null || name.trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Name cannot be empty!");
            return;
        }
        String depositStr = JOptionPane.showInputDialog(this, "Enter initial deposit amount:");
        try {
            double deposit = Double.parseDouble(depositStr);
            Account account = new Account(nextAccountNumber, name, deposit);
            accounts.put(nextAccountNumber, account);
            JOptionPane.showMessageDialog(this, "Account created successfully.\nYour account number is: " + nextAccountNumber);
            nextAccountNumber++;
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Invalid deposit amount.");
        }
    }

    // Deposit money into an existing account
    private void depositMoney() {
        String accNumStr = JOptionPane.showInputDialog(this, "Enter your account number:");
        try {
            int accNum = Integer.parseInt(accNumStr);
            Account account = accounts.get(accNum);
            if (account != null) {
                String amountStr = JOptionPane.showInputDialog(this, "Enter the amount to deposit:");
                double amount = Double.parseDouble(amountStr);
                if (amount > 0) {
                    account.deposit(amount);
                    JOptionPane.showMessageDialog(this, "Deposit successful.\nNew balance: " + account.getBalance());
                } else {
                    JOptionPane.showMessageDialog(this, "Invalid deposit amount.");
                }
            } else {
                JOptionPane.showMessageDialog(this, "Account not found.");
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Invalid account number or amount.");
        }
    }

    // Withdraw money from an existing account
    private void withdrawMoney() {
        String accNumStr = JOptionPane.showInputDialog(this, "Enter your account number:");
        try {
            int accNum = Integer.parseInt(accNumStr);
            Account account = accounts.get(accNum);
            if (account != null) {
                String amountStr = JOptionPane.showInputDialog(this, "Enter the amount to withdraw:");
                double amount = Double.parseDouble(amountStr);
                if (amount > 0 && amount <= account.getBalance()) {
                    account.withdraw(amount);
                    JOptionPane.showMessageDialog(this, "Withdrawal successful.\nNew balance: " + account.getBalance());
                } else {
                    JOptionPane.showMessageDialog(this, "Invalid amount or insufficient balance.");
                }
            } else {
                JOptionPane.showMessageDialog(this, "Account not found.");
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Invalid account number or amount.");
        }
    }

    // Display the account details for a given account number
    private void displayAccount() {
        String accNumStr = JOptionPane.showInputDialog(this, "Enter your account number:");
        try {
            int accNum = Integer.parseInt(accNumStr);
            Account account = accounts.get(accNum);
            if (account != null) {
                JOptionPane.showMessageDialog(this, account.displayAccount());
            } else {
                JOptionPane.showMessageDialog(this, "Account not found.");
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Invalid account number.");
        }
    }

    // Main method to run the application
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            BankProjectUI ui = new BankProjectUI();
            ui.setVisible(true);
        });
    }
}
